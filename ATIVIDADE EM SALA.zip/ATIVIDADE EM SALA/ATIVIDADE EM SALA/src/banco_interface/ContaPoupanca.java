package banco_interface;

public class ContaPoupanca implements Conta {
    private double saldo;

    @Override
    public double getSaldo() {
        return saldo;
    }

    @Override
    public void deposita(double valor) {
        saldo += valor;
    }

    @Override
    public void retira(double valor) {
        saldo -= valor;
    }

    @Override
    public void atualiza(double taxaSelic) {
        saldo += saldo * taxaSelic * 2; // Atualiza-se com o dobro da taxa Selic
    }
}
