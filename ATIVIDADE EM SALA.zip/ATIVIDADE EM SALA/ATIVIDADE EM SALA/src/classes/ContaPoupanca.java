package classes;

public class ContaPoupanca extends Conta {

    @Override
    public void atualiza(double taxa) {
        double saldoAtual = getSaldo();
        double novoSaldo = saldoAtual + (saldoAtual * taxa * 3); // Atualiza-se com o triplo da taxa
        setSaldo(novoSaldo);
    }
}
