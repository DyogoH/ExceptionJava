package classes;

public abstract class Conta {
    private double saldo;

     void deposita(double valor) throws ValorInvalidoException {
       if (valor < 0) {
        throw new ValorInvalidoException(valor);
    } else {
        this.saldo += valor - 0.10;
    }
    }

    public abstract void atualiza(double taxa);

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
